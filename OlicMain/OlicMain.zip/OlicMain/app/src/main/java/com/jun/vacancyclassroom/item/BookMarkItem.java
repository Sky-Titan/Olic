package com.jun.vacancyclassroom.item;

import android.widget.Button;

public class BookMarkItem {
    private String classroom;
    private String time;
    private int button_color;

    public String getClassroom() {
        return classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getButton_color() {
        return button_color;
    }

    public void setButton_color(int button_color) {
        this.button_color = button_color;
    }
}
